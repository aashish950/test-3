package com.expensetracker;
import android.app.Activity;
import android.os.Bundle;
public class ExportActivity extends Activity {
    @Override protected void onCreate(Bundle s) { super.onCreate(s); finish(); }
}
