package com.expensetracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    static final String NAME = "expense_tracker.db";
    static final int VER = 1;
    public DB(Context ctx) { super(ctx, NAME, null, VER); }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transactions (id TEXT PRIMARY KEY,date TEXT,amount REAL,type TEXT,merchant TEXT,category TEXT,bank TEXT,balance REAL,raw_sms TEXT,created_ms INTEGER)");
        db.execSQL("CREATE INDEX idx_date ON transactions(date)");
        db.execSQL("CREATE INDEX idx_cat ON transactions(category)");
    }
    public void onUpgrade(SQLiteDatabase db, int o, int n) { db.execSQL("DROP TABLE IF EXISTS transactions"); onCreate(db); }

    public void insertTxn(Map<String,Object> t) {
        ContentValues v = new ContentValues();
        v.put("id", String.valueOf(t.get("id")));
        v.put("date", String.valueOf(t.get("date")));
        v.put("amount", toD(t.get("amount")));
        v.put("type", String.valueOf(t.getOrDefault("type","debit")));
        v.put("merchant", String.valueOf(t.getOrDefault("merchant","Unknown")));
        v.put("category", String.valueOf(t.getOrDefault("category","Other")));
        v.put("bank", String.valueOf(t.getOrDefault("bank","Bank")));
        v.put("created_ms", System.currentTimeMillis());
        if (t.get("balance") != null) v.put("balance", toD(t.get("balance")));
        if (t.get("rawSms") != null) v.put("raw_sms", String.valueOf(t.get("rawSms")));
        getWritableDatabase().insertWithOnConflict("transactions", null, v, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void updateCategory(String id, String cat) {
        ContentValues v = new ContentValues(); v.put("category", cat);
        getWritableDatabase().update("transactions", v, "id=?", new String[]{id});
    }

    public void deleteTxn(String id) {
        if (id == null || id.isEmpty()) return;
        getWritableDatabase().delete("transactions", "id=?", new String[]{id});
    }

    public Set<String> existingIds() {
        Set<String> ids = new HashSet<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM transactions", null);
        try { while (c.moveToNext()) ids.add(c.getString(0)); } finally { c.close(); }
        return ids;
    }

    public List<String> getMonths() {
        List<String> m = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT DISTINCT substr(date,1,7) AS m FROM transactions ORDER BY m DESC", null);
        try { while (c.moveToNext()) m.add(c.getString(0)); } finally { c.close(); }
        return m;
    }

    public long totalCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM transactions", null);
        try { return c.moveToFirst() ? c.getLong(0) : 0; } finally { c.close(); }
    }

    public Map<String,Object> monthStats(String month) {
        Map<String,Object> out = new HashMap<>();
        String w = month.isEmpty() ? "1=1" : "substr(date,1,7)=?";
        String[] a = month.isEmpty() ? new String[]{} : new String[]{month};
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT SUM(CASE WHEN type='debit' THEN amount ELSE 0 END),SUM(CASE WHEN type='credit' THEN amount ELSE 0 END),COUNT(*) FROM transactions WHERE "+w, a);
        try { if (c.moveToFirst()) { out.put("spent", c.isNull(0)?0.0:c.getDouble(0)); out.put("received", c.isNull(1)?0.0:c.getDouble(1)); out.put("count", c.getInt(2)); } } finally { c.close(); }
        return out;
    }

    public Map<String,Double> catBreakdown(String month) {
        Map<String,Double> out = new LinkedHashMap<>();
        String w = month.isEmpty() ? "type='debit'" : "type='debit' AND substr(date,1,7)=?";
        String[] a = month.isEmpty() ? new String[]{} : new String[]{month};
        Cursor c = getReadableDatabase().rawQuery("SELECT category,SUM(amount) FROM transactions WHERE "+w+" GROUP BY category ORDER BY SUM(amount) DESC", a);
        try { while (c.moveToNext()) out.put(c.getString(0), c.getDouble(1)); } finally { c.close(); }
        return out;
    }

    public List<Map<String,Object>> getTxns(String month, String category, String type, String search, int limit) {
        List<Map<String,Object>> out = new ArrayList<>();
        StringBuilder w = new StringBuilder("1=1");
        List<String> args = new ArrayList<>();
        if (!month.isEmpty()) { w.append(" AND substr(date,1,7)=?"); args.add(month); }
        if (!"All".equals(category) && !category.isEmpty()) { w.append(" AND category=?"); args.add(category); }
        if (!"all".equals(type) && !type.isEmpty()) { w.append(" AND type=?"); args.add(type); }
        if (!search.isEmpty()) { w.append(" AND (merchant LIKE ? OR bank LIKE ? OR category LIKE ?)"); String q="%"+search+"%"; args.add(q); args.add(q); args.add(q); }
        String lc = limit > 0 ? " LIMIT "+limit : "";
        Cursor c = getReadableDatabase().rawQuery("SELECT id,date,amount,type,merchant,category,bank,balance,raw_sms FROM transactions WHERE "+w+" ORDER BY date DESC,created_ms DESC"+lc, args.toArray(new String[0]));
        try {
            while (c.moveToNext()) {
                Map<String,Object> t = new LinkedHashMap<>();
                t.put("id",c.getString(0)); t.put("date",c.getString(1)); t.put("amount",c.getDouble(2));
                t.put("type",c.getString(3)); t.put("merchant",c.getString(4)); t.put("category",c.getString(5));
                t.put("bank",c.getString(6)); t.put("balance",c.isNull(7)?null:c.getDouble(7));
                t.put("rawSms",c.isNull(8)?"":c.getString(8)); out.add(t);
            }
        } finally { c.close(); }
        return out;
    }

    private double toD(Object o) { if (o==null) return 0.0; if (o instanceof Number) return ((Number)o).doubleValue(); try { return Double.parseDouble(String.valueOf(o)); } catch (Exception e) { return 0.0; } }
}
