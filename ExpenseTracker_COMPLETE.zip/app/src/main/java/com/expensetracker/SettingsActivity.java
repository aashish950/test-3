package com.expensetracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class SettingsActivity extends Activity {

    SharedPreferences prefs;
    DB db;
    EditText apiKeyEt, budgetEt;
    CheckBox autoSyncCb;
    TextView saveMsgTv;
    boolean keyVisible = false;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        prefs = getSharedPreferences("et", MODE_PRIVATE);
        db = new DB(this);
        buildUI();
    }

    void buildUI() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFFF4F6FA);
        setContentView(page);

        // Toolbar
        LinearLayout tb = new LinearLayout(this);
        tb.setOrientation(LinearLayout.HORIZONTAL);
        tb.setBackgroundColor(0xFF378ADD);
        tb.setPadding(dp(10), 0, dp(10), 0);
        tb.setGravity(Gravity.CENTER_VERTICAL);
        tb.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(54)));
        Button back = new Button(this); back.setText("< Back");
        back.setTextColor(0xFFFFFFFF); back.setBackgroundColor(0xFF378ADD); back.setTextSize(14);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        tb.addView(back);
        TextView ttl = new TextView(this); ttl.setText("Settings");
        ttl.setTextSize(17); ttl.setTextColor(0xFFFFFFFF); ttl.setTypeface(null, Typeface.BOLD);
        tb.addView(ttl);
        page.addView(tb);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(8), dp(12), dp(48));
        sv.addView(root);
        page.addView(sv);

        // ── Stats card ────────────────────────────────────────────────────
        LinearLayout statsCard = card(root);
        addLabel(statsCard, "Overview");
        long cnt = db.totalCount();
        String ls = prefs.getString("last_sync", "Never");
        addInfoRow(statsCard, "Total transactions", String.valueOf(cnt));
        addInfoRow(statsCard, "Last sync", ls);

        // ── API Key card ──────────────────────────────────────────────────
        LinearLayout keyCard = card(root);
        addLabel(keyCard, "Anthropic API Key");
        addDesc(keyCard, "Powers AI SMS categorization. New accounts get $5 free credit (~3 months personal use).");

        LinearLayout keyRow = new LinearLayout(this);
        keyRow.setOrientation(LinearLayout.HORIZONTAL);
        keyRow.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        apiKeyEt = new EditText(this);
        apiKeyEt.setText(prefs.getString("api_key", ""));
        apiKeyEt.setHint("sk-ant-api03-...");
        apiKeyEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKeyEt.setTextSize(13);
        apiKeyEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        apiKeyEt.setBackgroundColor(0xFFF4F6FA);
        apiKeyEt.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        keyRow.addView(apiKeyEt);

        final Button eyeBtn = new Button(this);
        eyeBtn.setText("Show");
        eyeBtn.setTextSize(11); eyeBtn.setTextColor(0xFF888888);
        eyeBtn.setBackgroundColor(0xFFF4F6FA);
        eyeBtn.setPadding(dp(8), dp(4), dp(8), dp(4));
        eyeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                keyVisible = !keyVisible;
                if (keyVisible) {
                    apiKeyEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eyeBtn.setText("Hide");
                } else {
                    apiKeyEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eyeBtn.setText("Show");
                }
                apiKeyEt.setSelection(apiKeyEt.getText().length());
            }
        });
        keyRow.addView(eyeBtn);
        keyCard.addView(keyRow);
        addVspace(keyCard, 8);

        Button getKeyBtn = new Button(this);
        getKeyBtn.setText("Get free key at console.anthropic.com");
        getKeyBtn.setTextColor(0xFF378ADD); getKeyBtn.setBackgroundColor(0xFFE6F1FB);
        getKeyBtn.setTextSize(12); getKeyBtn.setPadding(dp(12), dp(8), dp(12), dp(8));
        getKeyBtn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        getKeyBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://console.anthropic.com")));
            }
        });
        keyCard.addView(getKeyBtn);
        addVspace(keyCard, 8);

        LinearLayout infoBox = new LinearLayout(this);
        infoBox.setOrientation(LinearLayout.VERTICAL);
        infoBox.setBackgroundColor(0xFFE6F1FB);
        infoBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        infoBox.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView infoTv = new TextView(this);
        infoTv.setText("Cost: ~50 SMS/month = Rs.3/month using Haiku model. $5 free credit on signup = 3-4 months free.");
        infoTv.setTextSize(12); infoTv.setTextColor(0xFF185FA5);
        infoBox.addView(infoTv);
        keyCard.addView(infoBox);

        // ── Budget card ───────────────────────────────────────────────────
        LinearLayout budgetCard = card(root);
        addLabel(budgetCard, "Monthly Budget (optional)");
        addDesc(budgetCard, "Set a spending budget for tracking.");
        LinearLayout budRow = new LinearLayout(this);
        budRow.setOrientation(LinearLayout.HORIZONTAL);
        budRow.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView rs = new TextView(this); rs.setText("Rs. "); rs.setTextSize(15); rs.setTextColor(0xFF666666);
        budRow.addView(rs);
        budgetEt = new EditText(this);
        int cur = prefs.getInt("budget", 0);
        budgetEt.setText(cur > 0 ? String.valueOf(cur) : "");
        budgetEt.setHint("e.g. 25000");
        budgetEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        budgetEt.setTextSize(14); budgetEt.setPadding(dp(10), dp(8), dp(10), dp(8));
        budgetEt.setBackgroundColor(0xFFF4F6FA);
        budgetEt.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        budRow.addView(budgetEt);
        budgetCard.addView(budRow);

        // ── Preferences card ──────────────────────────────────────────────
        LinearLayout prefCard = card(root);
        addLabel(prefCard, "Preferences");
        LinearLayout autoRow = new LinearLayout(this);
        autoRow.setOrientation(LinearLayout.HORIZONTAL);
        autoRow.setGravity(Gravity.CENTER_VERTICAL);
        autoRow.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        TextView al = new TextView(this); al.setText("Auto-sync on app open"); al.setTextSize(14); al.setTextColor(0xFF333333); al.setTypeface(null, Typeface.BOLD);
        col.addView(al);
        TextView ad = new TextView(this); ad.setText("Check for new SMS each launch"); ad.setTextSize(12); ad.setTextColor(0xFF888888);
        col.addView(ad);
        autoRow.addView(col);
        autoSyncCb = new CheckBox(this);
        autoSyncCb.setChecked(prefs.getBoolean("auto_sync", true));
        autoRow.addView(autoSyncCb);
        prefCard.addView(autoRow);

        // ── Save button ───────────────────────────────────────────────────
        Button saveBtn = new Button(this);
        saveBtn.setText("Save Settings");
        saveBtn.setTextColor(0xFFFFFFFF); saveBtn.setBackgroundColor(0xFF378ADD);
        saveBtn.setTextSize(16); saveBtn.setPadding(dp(20), dp(14), dp(20), dp(14));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(14), 0, dp(6));
        saveBtn.setLayoutParams(slp);
        saveBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doSave(); } });
        root.addView(saveBtn);

        saveMsgTv = new TextView(this);
        saveMsgTv.setTextSize(13); saveMsgTv.setTextColor(0xFF27500A);
        saveMsgTv.setGravity(Gravity.CENTER);
        root.addView(saveMsgTv);

        // ── Export card ───────────────────────────────────────────────────
        LinearLayout expCard = card(root);
        addLabel(expCard, "Export All Data");
        addDesc(expCard, "Download all transactions as CSV. Opens share sheet to save to Drive, email, WhatsApp, etc.");
        Button expBtn = new Button(this);
        expBtn.setText("Export All Transactions");
        expBtn.setTextColor(0xFF185FA5); expBtn.setBackgroundColor(0xFFE6F1FB);
        expBtn.setTextSize(14); expBtn.setPadding(dp(12), dp(10), dp(12), dp(10));
        expBtn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        expBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doExportAll(); } });
        expCard.addView(expBtn);

        // ── Danger zone ───────────────────────────────────────────────────
        LinearLayout dangerCard = card(root);
        TextView dl = new TextView(this); dl.setText("Danger Zone"); dl.setTextSize(14);
        dl.setTextColor(0xFFA32D2D); dl.setTypeface(null, Typeface.BOLD);
        dl.setPadding(0, 0, 0, dp(8)); dangerCard.addView(dl);
        Button clearBtn = new Button(this);
        clearBtn.setText("Clear All Transaction Data");
        clearBtn.setTextColor(0xFFA32D2D); clearBtn.setBackgroundColor(0xFFFCEBEB);
        clearBtn.setTextSize(13); clearBtn.setPadding(dp(12), dp(10), dp(12), dp(10));
        clearBtn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        clearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this)
                    .setTitle("Clear All Data")
                    .setMessage("This permanently deletes all saved transactions. Cannot be undone.")
                    .setPositiveButton("Clear All", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            getApplicationContext().deleteDatabase("expense_tracker.db");
                            Toast.makeText(SettingsActivity.this, "All data cleared.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null).show();
            }
        });
        dangerCard.addView(clearBtn);

        // ── Privacy note ──────────────────────────────────────────────────
        LinearLayout privBox = new LinearLayout(this);
        privBox.setOrientation(LinearLayout.VERTICAL);
        privBox.setBackgroundColor(0xFFEAF3DE);
        privBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.setMargins(0, dp(10), 0, 0); privBox.setLayoutParams(plp);
        TextView pt = new TextView(this);
        pt.setText("Privacy: All data stored on your phone only. Only SMS text is sent to Anthropic for AI parsing. Nothing else goes to any server.");
        pt.setTextSize(12); pt.setTextColor(0xFF3B6D11);
        privBox.addView(pt);
        root.addView(privBox);
    }

    void doSave() {
        String key = apiKeyEt.getText().toString().trim();
        if (!key.isEmpty() && !key.startsWith("sk-ant-")) {
            Toast.makeText(this, "API keys start with sk-ant-. Get yours at console.anthropic.com", Toast.LENGTH_LONG).show();
            return;
        }
        int budget = 0;
        try { budget = Integer.parseInt(budgetEt.getText().toString().trim()); } catch (Exception ignored) {}
        prefs.edit()
            .putString("api_key", key)
            .putBoolean("auto_sync", autoSyncCb.isChecked())
            .putInt("budget", budget)
            .apply();
        saveMsgTv.setText("Saved!");
        final TextView tv = saveMsgTv;
        new android.os.Handler().postDelayed(new Runnable() { public void run() { tv.setText(""); } }, 2500);
    }

    void doExportAll() {
        List<Map<String, Object>> txns = db.getTxns("", "All", "all", "", 99999);
        if (txns.isEmpty()) { Toast.makeText(this, "No data to export.", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("Export All Data")
            .setItems(new String[]{"Detailed CSV (all transactions)", "Monthly Summary CSV"}, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    List<Map<String, Object>> data = db.getTxns("", "All", "all", "", 99999);
                    String csv = which == 1 ? summaryCSV(data) : detailCSV(data);
                    String name = which == 1 ? "expense_summary.csv" : "transactions.csv";
                    try {
                        File dir = new File(getExternalFilesDir(null), "exports"); dir.mkdirs();
                        File f = new File(dir, name);
                        FileWriter fw = new FileWriter(f); fw.write(csv); fw.close();
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain"); i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
                        startActivity(Intent.createChooser(i, "Share via..."));
                    } catch (Exception e) { Toast.makeText(SettingsActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
                }
            }).setNegativeButton("Cancel", null).show();
    }

    String detailCSV(List<Map<String, Object>> txns) {
        StringBuilder sb = new StringBuilder("Date,Bank,Type,Amount (Rs),Merchant,Category,Balance (Rs)\n");
        for (Map<String, Object> t : txns) {
            sb.append(t.get("date")).append(",").append(t.get("bank")).append(",")
              .append(t.get("type")).append(",").append(fmt((double) t.getOrDefault("amount", 0.0))).append(",")
              .append(esc(t.get("merchant"))).append(",").append(t.get("category")).append(",")
              .append(t.get("balance") != null ? fmt((double) t.get("balance")) : "").append("\n");
        }
        return sb.toString();
    }

    String summaryCSV(List<Map<String, Object>> txns) {
        Map<String, List<Map<String, Object>>> byM = new LinkedHashMap<>();
        for (Map<String, Object> t : txns) {
            String m = String.valueOf(t.get("date")).substring(0, 7);
            if (!byM.containsKey(m)) byM.put(m, new ArrayList<Map<String, Object>>());
            byM.get(m).add(t);
        }
        StringBuilder sb = new StringBuilder("Month,Total Spent (Rs),Total Received (Rs),Transactions");
        for (String c : MainActivity.CATEGORIES) sb.append(",").append(c);
        sb.append("\n");
        List<String> mlist = new ArrayList<>(byM.keySet());
        Collections.sort(mlist, Collections.reverseOrder());
        for (String m : mlist) {
            List<Map<String, Object>> mt = byM.get(m);
            double sp = 0, rv = 0;
            Map<String, Double> bc = new HashMap<>();
            for (Map<String, Object> t : mt) {
                double a = (double) t.getOrDefault("amount", 0.0);
                if ("debit".equals(t.get("type"))) { sp += a; String c = String.valueOf(t.get("category")); bc.put(c, bc.getOrDefault(c, 0.0) + a); }
                else rv += a;
            }
            try { String[] p = m.split("-"); Calendar c = Calendar.getInstance(); c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, 1); sb.append(new SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(c.getTime())); } catch (Exception e) { sb.append(m); }
            sb.append(",").append(fmt(sp)).append(",").append(fmt(rv)).append(",").append(mt.size());
            for (String c : MainActivity.CATEGORIES) sb.append(",").append(fmt(bc.getOrDefault(c, 0.0)));
            sb.append("\n");
        }
        return sb.toString();
    }

    // helpers
    LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setBackgroundColor(0xFFFFFFFF); c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0); c.setLayoutParams(lp);
        parent.addView(c); return c;
    }
    void addLabel(LinearLayout p, String txt) {
        TextView v = new TextView(this); v.setText(txt); v.setTextSize(14); v.setTextColor(0xFF1A1A1A); v.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(6)); v.setLayoutParams(lp);
        p.addView(v);
    }
    void addDesc(LinearLayout p, String txt) {
        TextView v = new TextView(this); v.setText(txt); v.setTextSize(12); v.setTextColor(0xFF888888);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(8)); v.setLayoutParams(lp);
        p.addView(v);
    }
    void addInfoRow(LinearLayout p, String lbl, String val) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(3), 0, dp(3)); row.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView l = new TextView(this); l.setText(lbl); l.setTextSize(13); l.setTextColor(0xFF888888); l.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(l);
        TextView v = new TextView(this); v.setText(val); v.setTextSize(13); v.setTextColor(0xFF1A1A1A); v.setTypeface(null, Typeface.BOLD);
        row.addView(v); p.addView(row);
    }
    void addVspace(LinearLayout p, int dpv) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dpv))); p.addView(v); }
    int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }
    String fmt(double v) { return String.format("%,.0f", v); }
    String esc(Object v) { if (v == null) return ""; String s = String.valueOf(v); if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\""; return s; }
}
