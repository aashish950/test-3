package com.expensetracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class TransactionsActivity extends Activity {

    DB db;
    LinearLayout listBox;
    EditText searchBox;
    String curMonth = "", curCat = "All", curType = "all";
    TextView totalTv, countTv;

    static final String[] TYPES     = {"All", "Debit (Spent)", "Credit (Received)"};
    static final String[] TYPE_VALS = {"all", "debit", "credit"};

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        db = new DB(this);
        curMonth = getIntent().getStringExtra("month") != null ? getIntent().getStringExtra("month") : "";
        curCat   = getIntent().getStringExtra("category") != null ? getIntent().getStringExtra("category") : "All";
        buildUI();
        loadData();
    }

    void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6FA);
        setContentView(root);

        // Toolbar
        LinearLayout tb = new LinearLayout(this);
        tb.setOrientation(LinearLayout.HORIZONTAL);
        tb.setBackgroundColor(0xFF378ADD);
        tb.setPadding(dp(10), 0, dp(10), 0);
        tb.setGravity(Gravity.CENTER_VERTICAL);
        tb.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(54)));

        Button back = new Button(this); back.setText("< Back");
        back.setTextColor(0xFFFFFFFF); back.setBackgroundColor(0xFF378ADD); back.setTextSize(14);
        back.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        tb.addView(back);

        TextView ttl = new TextView(this); ttl.setText("Transactions");
        ttl.setTextSize(16); ttl.setTextColor(0xFFFFFFFF); ttl.setTypeface(null, Typeface.BOLD);
        ttl.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        tb.addView(ttl);

        Button eb = new Button(this); eb.setText("Export");
        eb.setTextColor(0xFF378ADD); eb.setBackgroundColor(0xFFFFFFFF);
        eb.setTextSize(13); eb.setPadding(dp(12), dp(4), dp(12), dp(4));
        eb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doExport(); } });
        tb.addView(eb);
        root.addView(tb);

        // Search
        LinearLayout sr = new LinearLayout(this);
        sr.setOrientation(LinearLayout.HORIZONTAL);
        sr.setBackgroundColor(0xFFFFFFFF);
        sr.setPadding(dp(10), dp(8), dp(10), dp(8));
        sr.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        searchBox = new EditText(this);
        searchBox.setHint("Search merchant, bank, category...");
        searchBox.setTextSize(14);
        searchBox.setBackgroundColor(0xFFF4F6FA);
        searchBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        searchBox.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(40)));
        searchBox.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable e) { loadData(); }
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
        });
        sr.addView(searchBox);
        root.addView(sr);

        // Filter row
        HorizontalScrollView hf = new HorizontalScrollView(this);
        hf.setHorizontalScrollBarEnabled(false);
        hf.setBackgroundColor(0xFFFFFFFF);
        LinearLayout filterRow = new LinearLayout(this);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);
        filterRow.setPadding(dp(10), dp(4), dp(10), dp(8));

        final Button monthBtn = filterChip("Month: " + (curMonth.isEmpty() ? "All" : fmtMonth(curMonth)));
        monthBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickMonth(monthBtn); }
        });
        filterRow.addView(monthBtn);
        filterRow.addView(spacer(8));

        final Button catBtn = filterChip("Cat: " + curCat);
        catBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickCategory(catBtn); }
        });
        filterRow.addView(catBtn);
        filterRow.addView(spacer(8));

        final Button typeBtn = filterChip("Type: All");
        typeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickType(typeBtn); }
        });
        filterRow.addView(typeBtn);
        hf.addView(filterRow);
        root.addView(hf);

        // Totals
        LinearLayout totRow = new LinearLayout(this);
        totRow.setOrientation(LinearLayout.HORIZONTAL);
        totRow.setPadding(dp(12), dp(4), dp(12), dp(4));
        totRow.setBackgroundColor(0xFFF4F6FA);
        countTv = new TextView(this); countTv.setTextSize(11); countTv.setTextColor(0xFF888888);
        countTv.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        totRow.addView(countTv);
        totalTv = new TextView(this); totalTv.setTextSize(12); totalTv.setTextColor(0xFF333333);
        totalTv.setTypeface(null, Typeface.BOLD);
        totRow.addView(totalTv);
        root.addView(totRow);

        // List in scroll
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setPadding(dp(10), dp(4), dp(10), dp(24));
        sv.addView(listBox);
        root.addView(sv);
    }

    void loadData() {
        String q = searchBox != null ? searchBox.getText().toString().trim() : "";
        List<Map<String, Object>> txns = db.getTxns(curMonth, curCat, curType, q, 500);
        listBox.removeAllViews();

        double spent = 0, recv = 0;
        for (Map<String, Object> t : txns) {
            double a = (double) t.getOrDefault("amount", 0.0);
            if ("debit".equals(t.get("type"))) spent += a; else recv += a;
        }
        if (countTv != null) countTv.setText(txns.size() + " transactions");
        if (totalTv != null) totalTv.setText("Spent: Rs." + fmt(spent) + "  Got: Rs." + fmt(recv));

        if (txns.isEmpty()) {
            TextView et = new TextView(this); et.setText("No transactions found");
            et.setTextSize(15); et.setTextColor(0xFF888888);
            et.setGravity(Gravity.CENTER); et.setPadding(0, dp(48), 0, 0);
            et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            listBox.addView(et);
            return;
        }
        for (Map<String, Object> t : txns) listBox.addView(buildCard(t));
    }

    View buildCard(final Map<String, Object> t) {
        String cat = (String) t.getOrDefault("category", "Other");
        int idx    = catIdx(cat);
        int color  = idx >= 0 ? MainActivity.CAT_COLORS[idx] : 0xFF888888;
        boolean cr = "credit".equals(t.get("type"));
        final String id = (String) t.get("id");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackgroundColor(0xFFFFFFFF);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(lp);

        TextView ico = new TextView(this);
        ico.setText(idx >= 0 ? MainActivity.CAT_ICONS[idx] : "O");
        ico.setTextSize(14); ico.setTextColor(0xFFFFFFFF);
        ico.setWidth(dp(38)); ico.setHeight(dp(38));
        ico.setGravity(Gravity.CENTER);
        ico.setBackgroundColor(color);
        card.addView(ico);
        card.addView(spacer(10));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

        TextView mn = new TextView(this);
        mn.setText(String.valueOf(t.getOrDefault("merchant", "?")));
        mn.setTextSize(14); mn.setTextColor(0xFF1A1A1A); mn.setTypeface(null, Typeface.BOLD);
        body.addView(mn);

        TextView cb = new TextView(this);
        cb.setText(cat);
        cb.setTextSize(11); cb.setTextColor(color);
        cb.setBackgroundColor(Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)));
        cb.setPadding(dp(6), dp(2), dp(6), dp(2));
        body.addView(cb);

        TextView mt = new TextView(this);
        mt.setText(String.valueOf(t.getOrDefault("bank", "")) + " - " + t.getOrDefault("date", ""));
        mt.setTextSize(11); mt.setTextColor(0xFF888888);
        body.addView(mt);
        card.addView(body);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);

        TextView av = new TextView(this);
        av.setText((cr ? "+" : "-") + "Rs." + fmt((double) t.getOrDefault("amount", 0.0)));
        av.setTextSize(14); av.setTextColor(cr ? 0xFF27500A : 0xFFE24B4A);
        av.setTypeface(null, Typeface.BOLD);
        right.addView(av);

        Button editBtn = new Button(this);
        editBtn.setText("Edit cat");
        editBtn.setTextSize(10); editBtn.setTextColor(0xFF378ADD);
        editBtn.setBackgroundColor(0xFFE6F1FB);
        editBtn.setPadding(dp(6), dp(2), dp(6), dp(2));
        editBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { editCat(id, (String) t.getOrDefault("category", "Other")); }
        });
        right.addView(editBtn);

        Button del = new Button(this);
        del.setText("Del");
        del.setTextSize(10); del.setTextColor(0xFFCCCCCC);
        del.setBackgroundColor(0xFFFFFFFF);
        del.setPadding(dp(6), dp(2), dp(6), dp(2));
        del.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(TransactionsActivity.this)
                    .setTitle("Delete")
                    .setMessage("Delete this transaction?")
                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { db.deleteTxn(id); loadData(); }
                    })
                    .setNegativeButton("Cancel", null).show();
            }
        });
        right.addView(del);
        card.addView(right);

        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String raw = String.valueOf(t.getOrDefault("rawSms", ""));
                Object bal = t.get("balance");
                String msg = "Raw SMS:\n\n" + raw;
                if (bal != null) msg += "\n\nBalance: Rs." + fmt((double) bal);
                new AlertDialog.Builder(TransactionsActivity.this)
                    .setTitle(String.valueOf(t.getOrDefault("merchant", "")))
                    .setMessage(msg)
                    .setPositiveButton("OK", null).show();
            }
        });
        return card;
    }

    void pickMonth(final Button btn) {
        List<String> months = db.getMonths();
        final String[] items = new String[months.size() + 1];
        items[0] = "All months";
        final List<String> ml = months;
        for (int i = 0; i < months.size(); i++) items[i + 1] = fmtMonth(months.get(i)) + " (" + months.get(i) + ")";
        new AlertDialog.Builder(this).setTitle("Select Month")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    curMonth = which == 0 ? "" : ml.get(which - 1);
                    btn.setText("Month: " + (curMonth.isEmpty() ? "All" : fmtMonth(curMonth)));
                    loadData();
                }
            }).show();
    }

    void pickCategory(final Button btn) {
        final String[] items = new String[MainActivity.CATEGORIES.length + 1];
        items[0] = "All";
        System.arraycopy(MainActivity.CATEGORIES, 0, items, 1, MainActivity.CATEGORIES.length);
        new AlertDialog.Builder(this).setTitle("Select Category")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    curCat = which == 0 ? "All" : MainActivity.CATEGORIES[which - 1];
                    btn.setText("Cat: " + curCat);
                    loadData();
                }
            }).show();
    }

    void pickType(final Button btn) {
        new AlertDialog.Builder(this).setTitle("Transaction Type")
            .setItems(TYPES, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    curType = TYPE_VALS[which];
                    btn.setText("Type: " + TYPES[which]);
                    loadData();
                }
            }).show();
    }

    void editCat(final String id, String current) {
        final String[] items = new String[MainActivity.CATEGORIES.length];
        for (int i = 0; i < items.length; i++)
            items[i] = MainActivity.CAT_ICONS[i] + "  " + MainActivity.CATEGORIES[i];
        int cur = catIdx(current);
        new AlertDialog.Builder(this).setTitle("Change Category")
            .setSingleChoiceItems(items, cur, null)
            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    ListView lv = ((AlertDialog) d).getListView();
                    int chk = lv.getCheckedItemPosition();
                    if (chk >= 0) { db.updateCategory(id, MainActivity.CATEGORIES[chk]); loadData(); }
                }
            })
            .setNegativeButton("Cancel", null).show();
    }

    void doExport() {
        String q = searchBox != null ? searchBox.getText().toString().trim() : "";
        List<Map<String, Object>> txns = db.getTxns(curMonth, curCat, curType, q, 99999);
        if (txns.isEmpty()) { Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show(); return; }
        StringBuilder sb = new StringBuilder("Date,Bank,Type,Amount (Rs),Merchant,Category,Balance (Rs)\n");
        for (Map<String, Object> t : txns) {
            sb.append(t.get("date")).append(",").append(t.get("bank")).append(",")
              .append(t.get("type")).append(",").append(fmt((double) t.getOrDefault("amount", 0.0))).append(",")
              .append(esc(t.get("merchant"))).append(",").append(t.get("category")).append(",")
              .append(t.get("balance") != null ? fmt((double) t.get("balance")) : "").append("\n");
        }
        try {
            File dir = new File(getExternalFilesDir(null), "exports"); dir.mkdirs();
            File f   = new File(dir, "transactions.csv");
            FileWriter fw = new FileWriter(f); fw.write(sb.toString()); fw.close();
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain"); i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Share CSV via..."));
        } catch (Exception e) { Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    Button filterChip(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(11);
        b.setTextColor(0xFF378ADD); b.setBackgroundColor(0xFFE6F1FB);
        b.setPadding(dp(10), dp(3), dp(10), dp(3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(6), 0); b.setLayoutParams(lp);
        return b;
    }
    View spacer(int dpVal) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(dpVal), 1)); return v; }
    int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }
    int catIdx(String c) { for (int i = 0; i < MainActivity.CATEGORIES.length; i++) if (MainActivity.CATEGORIES[i].equals(c)) return i; return MainActivity.CATEGORIES.length - 1; }
    String fmt(double v) { return String.format("%,.0f", v); }
    String esc(Object v) { if (v == null) return ""; String s = String.valueOf(v); if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\""; return s; }
    String fmtMonth(String m) {
        try { String[] p = m.split("-"); Calendar c = Calendar.getInstance(); c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, 1); return new SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(c.getTime()); } catch (Exception e) { return m; }
    }
}
