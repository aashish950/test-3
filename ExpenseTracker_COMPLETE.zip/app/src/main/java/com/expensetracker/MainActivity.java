package com.expensetracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {

    static final int REQ_SMS = 1001;
    static final int C_PRIMARY = 0xFF378ADD;
    static final int C_BG      = 0xFFF4F6FA;
    static final int C_WHITE   = 0xFFFFFFFF;
    static final int C_TEXT    = 0xFF1A1A1A;
    static final int C_MUTED   = 0xFF888888;
    static final int C_DEBIT   = 0xFFE24B4A;
    static final int C_CREDIT  = 0xFF27500A;
    static final int C_BORDER  = 0xFFE8E8E8;
    static final int C_INFO_BG = 0xFFE6F1FB;
    static final int C_WARN_BG = 0xFFFFF8E1;
    static final int C_WARN_TX = 0xFF854F0B;

    static final String[] CATEGORIES = {
        "Food & Dining","Shopping","Transport","Fuel","Groceries",
        "Utilities","Entertainment","Health","Travel","Education",
        "Finance & EMI","UPI Transfer","ATM Withdrawal","Other"
    };
    static final String[] CAT_ICONS = {
        "F","S","T","P","G","U","E","H","A","D","B","M","W","O"
    };
    static final int[] CAT_COLORS = {
        0xFFE24B4A,0xFFEF9F27,0xFF378ADD,0xFFBA7517,0xFF639922,
        0xFF533AB7,0xFF7F77DD,0xFF1D9E75,0xFFD85A30,0xFF534AB7,
        0xFF888780,0xFF185FA5,0xFF5F5E5A,0xFFB4B2A9
    };
    static final String[] BANK_SENDERS = {
        "HDFCBK","HDFC","SBIINB","SBI","ICICIB","ICICI","AXISBK","AXIS",
        "KOTAKB","KOTAK","YESBNK","INDBNK","PNBSMS","PNB","BOIIND","BOI",
        "CANBNK","IDFCFB","AUBANK","SCBANK","RBLBNK","FEDBK",
        "PAYTMB","PAYTM","AMZPAY","PHONEPE",
        "JD-HDFCB","AD-HDFCB","VM-HDFCBK","AD-SBIINB","VM-SBIINB",
        "AD-ICICIB","VM-ICICIB","BZ-AXISBK","VM-AXISBK","TP-KOTAK"
    };
    static final String[] TXN_KW = {
        "debited","credited","spent","payment","upi","neft","imps",
        "atm","transfer","received","withdrawn","purchase","txn",
        "rs.","inr","debit","credit"
    };

    DB db;
    SharedPreferences prefs;
    ScrollView mainScroll;
    LinearLayout mainContent;
    TextView syncStatusTv;
    String selMonth = "";

    @Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        db = new DB(this);
        prefs = getSharedPreferences("et", MODE_PRIVATE);
        buildUI();
        if (prefs.getBoolean("auto_sync", true) && !prefs.getString("api_key","").isEmpty()) {
            checkPermSync();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDash();
    }

    void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        setContentView(root);

        // ── Toolbar ──────────────────────────────────────────────────────
        LinearLayout tb = new LinearLayout(this);
        tb.setOrientation(LinearLayout.HORIZONTAL);
        tb.setBackgroundColor(C_PRIMARY);
        tb.setPadding(dp(12), 0, dp(12), 0);
        tb.setGravity(Gravity.CENTER_VERTICAL);
        tb.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(54)));

        TextView ttl = new TextView(this);
        ttl.setText("Expense Tracker");
        ttl.setTextSize(17); ttl.setTextColor(C_WHITE);
        ttl.setTypeface(null, Typeface.BOLD);
        ttl.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        tb.addView(ttl);

        Button syncBtn = new Button(this);
        syncBtn.setText("Sync");
        syncBtn.setTextColor(C_WHITE);
        syncBtn.setBackgroundColor(0xFF185FA5);
        syncBtn.setTextSize(13);
        syncBtn.setPadding(dp(14), dp(6), dp(14), dp(6));
        syncBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { checkPermSync(); }
        });
        tb.addView(syncBtn);

        View sp1 = new View(this); sp1.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        tb.addView(sp1);

        Button expBtn = new Button(this);
        expBtn.setText("Export");
        expBtn.setTextColor(C_PRIMARY);
        expBtn.setBackgroundColor(C_WHITE);
        expBtn.setTextSize(13);
        expBtn.setPadding(dp(12), dp(6), dp(12), dp(6));
        expBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showExport(); }
        });
        tb.addView(expBtn);

        View sp2 = new View(this); sp2.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        tb.addView(sp2);

        Button setBtn = new Button(this);
        setBtn.setText("Settings");
        setBtn.setTextColor(C_WHITE);
        setBtn.setBackgroundColor(0xFF185FA5);
        setBtn.setTextSize(12);
        setBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
        setBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        tb.addView(setBtn);
        root.addView(tb);

        // ── Sync status ──────────────────────────────────────────────────
        syncStatusTv = new TextView(this);
        syncStatusTv.setTextSize(12);
        syncStatusTv.setTextColor(0xFF185FA5);
        syncStatusTv.setBackgroundColor(C_INFO_BG);
        syncStatusTv.setPadding(dp(16), dp(6), dp(16), dp(6));
        syncStatusTv.setVisibility(View.GONE);
        root.addView(syncStatusTv);

        // ── Scroll content ───────────────────────────────────────────────
        mainScroll = new ScrollView(this);
        mainScroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1));
        mainContent = new LinearLayout(this);
        mainContent.setOrientation(LinearLayout.VERTICAL);
        mainContent.setPadding(dp(10), dp(10), dp(10), dp(24));
        mainScroll.addView(mainContent);
        root.addView(mainScroll);
    }

    void refreshDash() {
        mainContent.removeAllViews();
        String apiKey = prefs.getString("api_key", "");

        if (apiKey.isEmpty()) {
            LinearLayout warn = new LinearLayout(this);
            warn.setOrientation(LinearLayout.HORIZONTAL);
            warn.setBackgroundColor(C_WARN_BG);
            warn.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
            wlp.setMargins(0, 0, 0, dp(10));
            warn.setLayoutParams(wlp);
            TextView wt = new TextView(this);
            wt.setText("Add your Anthropic API key in Settings to start syncing");
            wt.setTextSize(13); wt.setTextColor(C_WARN_TX);
            warn.addView(wt);
            warn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                }
            });
            mainContent.addView(warn);
        }

        List<String> months = db.getMonths();
        if (months.isEmpty()) {
            showEmpty();
            return;
        }
        if (selMonth.isEmpty()) selMonth = months.get(0);

        // Month chips
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(0, dp(6), 0, dp(6));

        for (int i = 0; i < months.size(); i++) {
            final String m = months.get(i);
            Button chip = new Button(this);
            chip.setText(fmtMonth(m));
            chip.setTextSize(12);
            boolean active = m.equals(selMonth);
            chip.setTextColor(active ? C_WHITE : C_MUTED);
            chip.setBackgroundColor(active ? C_PRIMARY : C_WHITE);
            chip.setPadding(dp(14), dp(4), dp(14), dp(4));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
            clp.setMargins(0, 0, dp(8), 0);
            chip.setLayoutParams(clp);
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { selMonth = m; refreshDash(); }
            });
            chipRow.addView(chip);
        }
        hs.addView(chipRow);
        mainContent.addView(hs);

        // Stats
        Map<String, Object> stats = db.monthStats(selMonth);
        double spent    = getD(stats, "spent");
        double received = getD(stats, "received");
        int    count    = getI(stats, "count");

        LinearLayout krow = new LinearLayout(this);
        krow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams krlp = new LinearLayout.LayoutParams(-1, -2);
        krlp.setMargins(0, 0, 0, dp(10));
        krow.setLayoutParams(krlp);

        krow.addView(kpiCard("Total Spent",  "Rs." + fmtN(spent),    count + " txns",  C_DEBIT));
        View ks = new View(this); ks.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1)); krow.addView(ks);
        krow.addView(kpiCard("Received",     "Rs." + fmtN(received), "credits",        C_CREDIT));
        View ks2 = new View(this); ks2.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1)); krow.addView(ks2);
        krow.addView(kpiCard("Daily Avg",    "Rs." + fmtN(spent/30), "per day",        C_PRIMARY));
        mainContent.addView(krow);

        // Category breakdown
        Map<String, Double> byCat = db.catBreakdown(selMonth);
        if (!byCat.isEmpty()) {
            LinearLayout card = makeCard();
            TextView hdr = new TextView(this);
            hdr.setText("By Category  |  Tap to filter");
            hdr.setTextSize(14); hdr.setTextColor(C_TEXT);
            hdr.setTypeface(null, Typeface.BOLD);
            hdr.setPadding(0, 0, 0, dp(8));
            card.addView(hdr);

            List<Map.Entry<String, Double>> sorted = new ArrayList<>(byCat.entrySet());
            Collections.sort(sorted, new Comparator<Map.Entry<String, Double>>() {
                public int compare(Map.Entry<String, Double> a, Map.Entry<String, Double> b) {
                    return Double.compare(b.getValue(), a.getValue());
                }
            });

            for (Map.Entry<String, Double> e : sorted) {
                final String cat = e.getKey();
                double amt = e.getValue();
                card.addView(catRow(cat, amt, spent));
            }
            mainContent.addView(card);
            View spc = new View(this);
            spc.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(10)));
            mainContent.addView(spc);
        }

        // Recent transactions
        List<Map<String, Object>> recent = db.getTxns(selMonth, "All", "debit", "", 6);
        if (!recent.isEmpty()) {
            LinearLayout card2 = makeCard();
            LinearLayout ch = new LinearLayout(this);
            ch.setOrientation(LinearLayout.HORIZONTAL);
            ch.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            TextView ht = new TextView(this);
            ht.setText("Recent Transactions");
            ht.setTextSize(14); ht.setTextColor(C_TEXT);
            ht.setTypeface(null, Typeface.BOLD);
            ht.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
            ch.addView(ht);
            Button seeAll = new Button(this);
            seeAll.setText("See all");
            seeAll.setTextSize(12); seeAll.setTextColor(C_PRIMARY);
            seeAll.setBackgroundColor(C_WHITE);
            seeAll.setPadding(dp(8), dp(2), dp(8), dp(2));
            seeAll.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(MainActivity.this, TransactionsActivity.class);
                    i.putExtra("month", selMonth);
                    startActivity(i);
                }
            });
            ch.addView(seeAll);
            ch.setPadding(0, 0, 0, dp(8));
            card2.addView(ch);
            for (Map<String, Object> t : recent) card2.addView(txnRow(t));
            mainContent.addView(card2);
            View spc2 = new View(this);
            spc2.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(10)));
            mainContent.addView(spc2);
        }

        // Export button
        Button eb = new Button(this);
        eb.setText("Download CSV / Excel export");
        eb.setTextColor(0xFF185FA5);
        eb.setBackgroundColor(C_INFO_BG);
        eb.setTextSize(14);
        eb.setPadding(dp(16), dp(12), dp(16), dp(12));
        eb.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        eb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showExport(); }
        });
        mainContent.addView(eb);

        String ls = prefs.getString("last_sync", "");
        if (!ls.isEmpty()) {
            TextView lst = new TextView(this);
            lst.setText("Last sync: " + ls);
            lst.setTextSize(11); lst.setTextColor(C_MUTED);
            lst.setPadding(0, dp(6), 0, 0);
            mainContent.addView(lst);
        }
    }

    void showEmpty() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(32), dp(48), dp(32), dp(48));
        TextView ico = new TextView(this); ico.setText("[SMS]"); ico.setTextSize(32);
        ico.setGravity(Gravity.CENTER); v.addView(ico);
        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(16))); v.addView(sp);
        TextView t1 = new TextView(this); t1.setText("No transactions yet");
        t1.setTextSize(18); t1.setTextColor(C_TEXT); t1.setTypeface(null, Typeface.BOLD);
        t1.setGravity(Gravity.CENTER); v.addView(t1);
        View sp2 = new View(this); sp2.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(8))); v.addView(sp2);
        TextView t2 = new TextView(this);
        t2.setText("Tap Sync to read your bank SMS and auto-categorize your spending.");
        t2.setTextSize(14); t2.setTextColor(C_MUTED); t2.setGravity(Gravity.CENTER); v.addView(t2);
        View sp3 = new View(this); sp3.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(24))); v.addView(sp3);
        Button b = new Button(this); b.setText("Sync Now");
        b.setTextColor(C_WHITE); b.setBackgroundColor(C_PRIMARY); b.setTextSize(15);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(160), dp(44));
        b.setLayoutParams(blp);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View vv) { checkPermSync(); }
        });
        v.addView(b);
        mainContent.addView(v);
    }

    LinearLayout kpiCard(String label, String value, String sub, int valColor) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        v.setBackgroundColor(C_WHITE);
        v.setPadding(dp(12), dp(12), dp(12), dp(12));
        TextView lbl = new TextView(this); lbl.setText(label);
        lbl.setTextSize(11); lbl.setTextColor(C_MUTED); v.addView(lbl);
        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(4))); v.addView(sp);
        TextView val = new TextView(this); val.setText(value);
        val.setTextSize(16); val.setTextColor(valColor); val.setTypeface(null, Typeface.BOLD); v.addView(val);
        TextView sv = new TextView(this); sv.setText(sub);
        sv.setTextSize(11); sv.setTextColor(C_MUTED); v.addView(sv);
        return v;
    }

    View catRow(final String cat, double amount, double total) {
        int idx   = catIdx(cat);
        int color = idx >= 0 ? CAT_COLORS[idx] : 0xFF888888;
        float pct = total > 0 ? (float)(amount / total * 100f) : 0f;

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, dp(8));
        row.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        TextView ico = new TextView(this);
        ico.setText(idx >= 0 ? CAT_ICONS[idx] : "O");
        ico.setTextSize(15); ico.setTextColor(C_WHITE);
        ico.setWidth(dp(36)); ico.setHeight(dp(36));
        ico.setGravity(Gravity.CENTER);
        ico.setBackgroundColor(color);
        row.addView(ico);

        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(dp(10), 1)); row.addView(sp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout lr = new LinearLayout(this);
        lr.setOrientation(LinearLayout.HORIZONTAL);
        lr.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView cn = new TextView(this); cn.setText(cat);
        cn.setTextSize(13); cn.setTextColor(C_TEXT); cn.setTypeface(null, Typeface.BOLD);
        cn.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        lr.addView(cn);
        TextView av = new TextView(this); av.setText("Rs." + fmtN(amount));
        av.setTextSize(13); av.setTextColor(C_TEXT); av.setTypeface(null, Typeface.BOLD);
        lr.addView(av);
        info.addView(lr);

        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100); pb.setProgress((int)pct);
        pb.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(4)));
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        info.addView(pb);

        TextView pp = new TextView(this); pp.setText(String.format("%.1f%%", pct));
        pp.setTextSize(11); pp.setTextColor(C_MUTED); info.addView(pp);
        row.addView(info);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, TransactionsActivity.class);
                i.putExtra("month", selMonth); i.putExtra("category", cat);
                startActivity(i);
            }
        });
        return row;
    }

    View txnRow(Map<String, Object> t) {
        String cat   = (String) t.getOrDefault("category", "Other");
        int idx      = catIdx(cat);
        int color    = idx >= 0 ? CAT_COLORS[idx] : 0xFF888888;
        boolean isCr = "credit".equals(t.get("type"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, dp(8));
        row.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        TextView ico = new TextView(this);
        ico.setText(idx >= 0 ? CAT_ICONS[idx] : "O");
        ico.setTextSize(14); ico.setTextColor(C_WHITE);
        ico.setWidth(dp(34)); ico.setHeight(dp(34));
        ico.setGravity(Gravity.CENTER);
        ico.setBackgroundColor(color);
        row.addView(ico);

        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(dp(10), 1)); row.addView(sp);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        TextView m = new TextView(this);
        m.setText(String.valueOf(t.getOrDefault("merchant", "?")));
        m.setTextSize(14); m.setTextColor(C_TEXT); m.setTypeface(null, Typeface.BOLD);
        body.addView(m);
        TextView meta = new TextView(this);
        meta.setText(t.get("bank") + " - " + t.get("date"));
        meta.setTextSize(11); meta.setTextColor(C_MUTED);
        body.addView(meta);
        row.addView(body);

        String sign = isCr ? "+" : "-";
        TextView amt = new TextView(this);
        amt.setText(sign + "Rs." + fmtN((double) t.getOrDefault("amount", 0.0)));
        amt.setTextSize(14); amt.setTextColor(isCr ? C_CREDIT : C_DEBIT);
        amt.setTypeface(null, Typeface.BOLD);
        row.addView(amt);

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        wrap.addView(row);
        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        div.setBackgroundColor(0xFFF0F0F0);
        wrap.addView(div);
        return wrap;
    }

    LinearLayout makeCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackgroundColor(C_WHITE);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        c.setLayoutParams(lp);
        return c;
    }

    // ── Sync ─────────────────────────────────────────────────────────────────

    void checkPermSync() {
        if (checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            doSync();
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_SMS}, REQ_SMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        if (req == REQ_SMS && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            doSync();
        } else {
            Toast.makeText(this, "SMS permission denied. Allow it in Settings > Apps > Expense Tracker > Permissions.", Toast.LENGTH_LONG).show();
        }
    }

    void doSync() {
        final String apiKey = prefs.getString("api_key", "");
        if (apiKey.isEmpty()) {
            new AlertDialog.Builder(this)
                .setTitle("API Key Required")
                .setMessage("Add your Anthropic API key in Settings.\n\nGet a free key at console.anthropic.com — new accounts get $5 free credit.")
                .setPositiveButton("Open Settings", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
            return;
        }
        new SyncTask(apiKey).execute();
    }

    class SyncTask extends AsyncTask<Void, String, String> {
        String apiKey;
        int added, skipped, errors;

        SyncTask(String key) { apiKey = key; }

        protected void onPreExecute() {
            syncStatusTv.setVisibility(View.VISIBLE);
            syncStatusTv.setText("Reading SMS...");
        }
        protected void onProgressUpdate(String... v) { syncStatusTv.setText(v[0]); }

        protected String doInBackground(Void... p) {
            try {
                publishProgress("Reading bank SMS from inbox...");
                List<String[]> allSms = readBankSMS();
                Set<String> existIds = db.existingIds();
                List<String[]> newSms = new ArrayList<>();
                for (String[] s : allSms) {
                    if (!existIds.contains(s[0])) newSms.add(s);
                }
                skipped = allSms.size() - newSms.size();
                publishProgress("Found " + allSms.size() + " bank SMS, " + newSms.size() + " new.");
                if (newSms.isEmpty()) return "ok";

                int total = (newSms.size() + 39) / 40;
                for (int b = 0; b < newSms.size(); b += 40) {
                    int bn = b / 40 + 1;
                    List<String[]> batch = newSms.subList(b, Math.min(b + 40, newSms.size()));
                    publishProgress("Parsing batch " + bn + "/" + total + " with AI...");
                    try {
                        List<Map<String, Object>> parsed = callClaude(apiKey, batch);
                        for (Map<String, Object> t : parsed) {
                            db.insertTxn(t);
                            added++;
                        }
                    } catch (Exception ex) {
                        errors++;
                    }
                }
                return "ok";
            } catch (Exception e) {
                return "error:" + e.getMessage();
            }
        }

        protected void onPostExecute(String result) {
            syncStatusTv.setVisibility(View.GONE);
            prefs.edit().putString("last_sync",
                new SimpleDateFormat("dd MMM hh:mm a", Locale.getDefault()).format(new Date())).apply();
            if (result.startsWith("error:")) {
                Toast.makeText(MainActivity.this, "Sync failed: " + result.substring(6), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(MainActivity.this, "Done! Added " + added + " transactions. Skipped " + skipped + "." + (errors > 0 ? " Errors: " + errors : ""), Toast.LENGTH_LONG).show();
            }
            refreshDash();
        }
    }

    // ── SMS Reading ───────────────────────────────────────────────────────────

    List<String[]> readBankSMS() {
        List<String[]> result = new ArrayList<>();
        Uri uri = Uri.parse("content://sms/inbox");
        String[] proj = {"_id", "address", "body", "date"};
        long since = System.currentTimeMillis() - 183L * 24 * 60 * 60 * 1000;
        Cursor c = getContentResolver().query(uri, proj, "date > ?", new String[]{String.valueOf(since)}, "date DESC");
        if (c == null) return result;
        try {
            while (c.moveToNext()) {
                String id   = c.getString(0);
                String addr = c.getString(1);
                String body = c.getString(2);
                String date = c.getString(3);
                if (isBankSMS(addr, body)) result.add(new String[]{id, addr, body, date});
            }
        } finally { c.close(); }
        return result;
    }

    boolean isBankSMS(String addr, String body) {
        if (addr == null || body == null) return false;
        String up = addr.toUpperCase();
        boolean bank = false;
        for (String s : BANK_SENDERS) if (up.contains(s)) { bank = true; break; }
        if (!bank) return false;
        String lo = body.toLowerCase();
        for (String kw : TXN_KW) if (lo.contains(kw)) return true;
        return false;
    }

    // ── Claude API ────────────────────────────────────────────────────────────

    List<Map<String, Object>> callClaude(String key, List<String[]> smsList) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < smsList.size(); i++) {
            String[] s = smsList.get(i);
            sb.append("[").append(i).append("] id=").append(s[0])
              .append(" sender=").append(s[1]).append(" ts=").append(s[3]).append("\n")
              .append(s[2]).append("\n---\n");
        }

        String sys = "You are a precise Indian bank SMS parser. Extract transaction data.\n"
            + "Return ONLY a JSON array, no markdown, no explanation.\n"
            + "For each transaction return: {\"id\":\"from id=xxx\",\"date\":\"YYYY-MM-DD\","
            + "\"amount\":1234.5,\"type\":\"debit or credit\",\"merchant\":\"name max 25 chars\","
            + "\"category\":\"one of: Food & Dining|Shopping|Transport|Fuel|Groceries|Utilities|"
            + "Entertainment|Health|Travel|Education|Finance & EMI|UPI Transfer|ATM Withdrawal|Other\","
            + "\"bank\":\"HDFC/SBI/ICICI/Axis/etc\",\"balance\":null or number}\n"
            + "Rules: Swiggy/Zomato/restaurant->Food & Dining; Amazon/Flipkart->Shopping; "
            + "Ola/Uber/Metro->Transport; Petrol/HP/BPCL->Fuel; BigBasket/DMart->Groceries; "
            + "Jio/Airtel/electricity->Utilities; Netflix/BookMyShow->Entertainment; "
            + "Hospital/pharmacy->Health; Flight/hotel/IRCTC->Travel; School/fee->Education; "
            + "EMI/LIC/SIP->Finance & EMI; UPI to person->UPI Transfer; ATM->ATM Withdrawal. "
            + "Skip OTPs and promos. Return [] if none found.";

        JSONObject payload = new JSONObject();
        payload.put("model", "claude-haiku-4-5-20251001");
        payload.put("max_tokens", 3000);
        payload.put("system", sys);
        JSONArray msgs = new JSONArray();
        JSONObject msg = new JSONObject();
        msg.put("role", "user");
        msg.put("content", sb.toString());
        msgs.put(msg);
        payload.put("messages", msgs);

        URL url = new URL("https://api.anthropic.com/v1/messages");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", key);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(45000);
        conn.getOutputStream().write(payload.toString().getBytes("UTF-8"));

        int code = conn.getResponseCode();
        InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder resp = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        String line;
        while ((line = br.readLine()) != null) resp.append(line);
        br.close();

        if (code != 200) throw new Exception("API " + code);

        JSONObject ro = new JSONObject(resp.toString());
        String txt    = ro.getJSONArray("content").getJSONObject(0).getString("text");
        String clean  = txt.replaceAll("```json", "").replaceAll("```", "").trim();
        int as        = clean.indexOf('[');
        if (as < 0) return new ArrayList<>();
        JSONArray arr = new JSONArray(clean.substring(as));

        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String id = o.optString("id", "");
            double amount = o.optDouble("amount", 0);
            if (id.isEmpty() || amount <= 0) continue;
            Map<String, Object> t = new LinkedHashMap<>();
            t.put("id",       id);
            t.put("date",     o.optString("date", today()));
            t.put("amount",   amount);
            t.put("type",     o.optString("type", "debit"));
            t.put("merchant", o.optString("merchant", "Unknown"));
            t.put("category", o.optString("category", "Other"));
            t.put("bank",     o.optString("bank", "Bank"));
            t.put("balance",  o.isNull("balance") ? null : o.optDouble("balance"));
            String rawSms = "";
            for (String[] s : smsList) if (s[0].equals(id)) { rawSms = s[2]; break; }
            t.put("rawSms",   rawSms);
            out.add(t);
        }
        return out;
    }

    // ── Export ────────────────────────────────────────────────────────────────

    void showExport() {
        List<Map<String, Object>> all = db.getTxns("", "All", "all", "", 99999);
        if (all.isEmpty()) { Toast.makeText(this, "No data to export.", Toast.LENGTH_SHORT).show(); return; }

        final List<Map<String, Object>> txns = all;
        String[] opts = {"Detailed CSV (all transactions)", "Monthly Summary CSV", "This month only"};
        new AlertDialog.Builder(this)
            .setTitle("Export Data")
            .setItems(opts, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    List<Map<String, Object>> data = which == 2
                        ? db.getTxns(selMonth, "All", "all", "", 99999)
                        : txns;
                    String csv  = which == 1 ? buildSummaryCSV(data) : buildDetailCSV(data);
                    String name = (which == 1 ? "expense_summary_" : "transactions_") + today() + ".csv";
                    shareCSV(csv, name);
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    String buildDetailCSV(List<Map<String, Object>> txns) {
        StringBuilder sb = new StringBuilder("Date,Bank,Type,Amount (Rs),Merchant,Category,Balance (Rs)\n");
        for (Map<String, Object> t : txns) {
            sb.append(t.get("date")).append(",")
              .append(t.get("bank")).append(",")
              .append(t.get("type")).append(",")
              .append(fmtN((double) t.getOrDefault("amount", 0.0))).append(",")
              .append(esc(t.get("merchant"))).append(",")
              .append(t.get("category")).append(",")
              .append(t.get("balance") != null ? fmtN((double) t.get("balance")) : "")
              .append("\n");
        }
        return sb.toString();
    }

    String buildSummaryCSV(List<Map<String, Object>> txns) {
        Map<String, List<Map<String, Object>>> byM = new LinkedHashMap<>();
        for (Map<String, Object> t : txns) {
            String m = String.valueOf(t.get("date")).substring(0, 7);
            if (!byM.containsKey(m)) byM.put(m, new ArrayList<Map<String, Object>>());
            byM.get(m).add(t);
        }
        StringBuilder sb = new StringBuilder("Month,Total Spent (Rs),Total Received (Rs),Transactions");
        for (String c : CATEGORIES) sb.append(",").append(c);
        sb.append("\n");
        List<String> mlist = new ArrayList<>(byM.keySet());
        Collections.sort(mlist, Collections.reverseOrder());
        for (String m : mlist) {
            List<Map<String, Object>> mt = byM.get(m);
            double spent = 0, recv = 0;
            Map<String, Double> bc = new HashMap<>();
            for (Map<String, Object> t : mt) {
                double a = (double) t.getOrDefault("amount", 0.0);
                if ("debit".equals(t.get("type"))) { spent += a; String c = String.valueOf(t.get("category")); bc.put(c, bc.getOrDefault(c, 0.0) + a); }
                else recv += a;
            }
            sb.append(fmtMonth(m)).append(",").append(fmtN(spent)).append(",").append(fmtN(recv)).append(",").append(mt.size());
            for (String c : CATEGORIES) sb.append(",").append(fmtN(bc.getOrDefault(c, 0.0)));
            sb.append("\n");
        }
        return sb.toString();
    }

    void shareCSV(String csv, String name) {
        try {
            File dir  = new File(getExternalFilesDir(null), "exports");
            dir.mkdirs();
            File file = new File(dir, name);
            FileWriter fw = new FileWriter(file);
            fw.write(csv);
            fw.close();
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Expense Export");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Share CSV via..."));
        } catch (Exception e) {
            Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    int dp(int d) { return Math.round(d * getResources().getDisplayMetrics().density); }
    int catIdx(String c) { for (int i = 0; i < CATEGORIES.length; i++) if (CATEGORIES[i].equals(c)) return i; return CATEGORIES.length - 1; }
    String fmtN(double v) { return String.format("%,.0f", v); }
    String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()); }
    String fmtMonth(String m) {
        try { String[] p = m.split("-"); Calendar c = Calendar.getInstance(); c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, 1); return new SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(c.getTime()); } catch (Exception e) { return m; }
    }
    String esc(Object v) { if (v == null) return ""; String s = String.valueOf(v); if (s.contains(",") || s.contains("\"")) return "\"" + s.replace("\"", "\"\"") + "\""; return s; }
    double getD(Map<String, Object> m, String k) { Object v = m.get(k); return v instanceof Number ? ((Number) v).doubleValue() : 0.0; }
    int    getI(Map<String, Object> m, String k) { Object v = m.get(k); return v instanceof Number ? ((Number) v).intValue() : 0; }
}
