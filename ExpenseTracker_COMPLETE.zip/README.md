# Expense Tracker - SMS AI Categorizer

## IMPORTANT: How to upload to GitHub correctly

GitHub drag-and-drop SKIPS hidden folders like `.github`. So you MUST do this in 2 steps:

### Step 1 - Upload all regular files
1. Create new GitHub repo (public)
2. Click "uploading an existing file"
3. Drag and drop EVERYTHING from this folder EXCEPT the `.github` folder
4. Click "Commit changes"

### Step 2 - Create the workflow manually (30 seconds)
1. Click the `.github` folder in this ZIP on your computer to find `build.yml`
2. In GitHub, click "Add file" -> "Create new file"
3. Type this exact filename: `.github/workflows/build.yml`
4. Copy-paste the entire content of `build.yml` from this ZIP
5. Click "Commit changes"
6. Build starts automatically! Wait 8-10 minutes -> green tick -> download APK

### Step 3 - First time using the app
1. Allow SMS permission
2. Go to Settings -> Enter your Anthropic API key
   (Free at console.anthropic.com - comes with $5 credit)
3. Tap Sync -> your expenses appear in 10-30 seconds
4. Tap Export to download CSV for Excel/Google Sheets
